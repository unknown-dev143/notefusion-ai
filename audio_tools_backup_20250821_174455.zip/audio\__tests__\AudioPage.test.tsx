import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import AudioPage from '../AudioPage';
import '@testing-library/jest-dom';

// Mock the audio context
window.AudioContext = jest.fn().mockImplementation(() => ({
  createMediaStreamDestination: jest.fn(),
  createMediaStreamSource: jest.fn(),
  suspend: jest.fn().mockResolvedValue(undefined),
  resume: jest.fn().mockResolvedValue(undefined),
  close: jest.fn().mockResolvedValue(undefined),
}));

// Mock the speech recognition
Object.defineProperty(window, 'SpeechRecognition', {
  value: class SpeechRecognition {
    start = jest.fn();
    stop = jest.fn();
    onresult = jest.fn();
    onerror = jest.fn();
    onend = jest.fn();
  },
});

// Mock the speech synthesis
Object.defineProperty(window, 'speechSynthesis', {
  value: {
    speak: jest.fn(),
    cancel: jest.fn(),
    getVoices: jest.fn().mockReturnValue([
      { name: 'Google US English', lang: 'en-US' },
      { name: 'Google UK English', lang: 'en-GB' },
    ]),
  },
  writable: true,
});

describe('AudioPage', () => {
  const renderComponent = () => {
    return render(
      <BrowserRouter>
        <AudioPage />
      </BrowserRouter>
    );
  };

  it('renders the audio tools page', () => {
    renderComponent();
    expect(screen.getByText('Audio Tools')).toBeInTheDocument();
    expect(screen.getByText('Text to Speech')).toBeInTheDocument();
    expect(screen.getByText('Speech to Text')).toBeInTheDocument();
  });

  it('allows text input for text-to-speech', () => {
    renderComponent();
    const input = screen.getByPlaceholderText('Enter text to convert to speech...');
    fireEvent.change(input, { target: { value: 'Hello, world!' } });
    expect(input).toHaveValue('Hello, world!');
  });

  it('displays voice selection dropdown', async () => {
    renderComponent();
    const voiceSelect = screen.getByLabelText('Select Voice');
    expect(voiceSelect).toBeInTheDocument();
    
    // Check if voices are loaded
    await waitFor(() => {
      expect(screen.getByText('Google US English')).toBeInTheDocument();
    });
  });

  it('handles start/stop recording', () => {
    renderComponent();
    const startButton = screen.getByText('Start Recording');
    fireEvent.click(startButton);
    
    // Should show recording indicator
    expect(screen.getByText('Recording...')).toBeInTheDocument();
    
    const stopButton = screen.getByText('Stop Recording');
    fireEvent.click(stopButton);
    
    // Should hide recording indicator
    expect(screen.queryByText('Recording...')).not.toBeInTheDocument();
  });

  it('displays recorded transcript', async () => {
    renderComponent();
    
    // Mock a speech recognition result
    const mockEvent = {
      results: [
        [
          { transcript: 'Hello, this is a test', confidence: 0.9 }
        ]
      ]
    };
    
    // Trigger the recognition result
    const recognition = new window.SpeechRecognition();
    recognition.onresult(mockEvent);
    
    // Check if transcript is displayed
    await waitFor(() => {
      expect(screen.getByText('Hello, this is a test')).toBeInTheDocument();
    });
  });

  it('handles playback controls', () => {
    renderComponent();
    
    // First add some text to enable the play button
    const input = screen.getByPlaceholderText('Enter text to convert to speech...');
    fireEvent.change(input, { target: { value: 'Test text' } });
    
    const playButton = screen.getByText('Play');
    fireEvent.click(playButton);
    
    // Should show pause button after clicking play
    expect(screen.getByText('Pause')).toBeInTheDocument();
    
    // Click pause
    fireEvent.click(screen.getByText('Pause'));
    
    // Should show play button again
    expect(screen.getByText('Play')).toBeInTheDocument();
  });
});
