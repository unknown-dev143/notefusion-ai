import React, { useState } from 'react';
import { Tabs, Card, Button, Space, Typography } from 'antd';
import { AudioOutlined, SoundOutlined } from '@ant-design/icons';
import { TextToSpeech } from '../components/TextToSpeech';
import { SpeechToText } from '../components/SpeechToText';

const { Title } = Typography;
const { TabPane } = Tabs;

export const AudioPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState('tts');

  return (
    <div className="audio-page">
      <Title level={2} className="page-title">
        <AudioOutlined /> Audio Tools
      </Title>
      
      <Card>
        <Tabs 
          activeKey={activeTab} 
          onChange={setActiveTab}
          animated
          tabBarExtraContent={
            <Button 
              type="text" 
              icon={activeTab === 'tts' ? <SoundOutlined /> : <AudioOutlined />}
              onClick={() => setActiveTab(activeTab === 'tts' ? 'stt' : 'tts')}
            >
              Switch to {activeTab === 'tts' ? 'Speech-to-Text' : 'Text-to-Speech'}
            </Button>
          }
        >
          <TabPane tab={
            <span><SoundOutlined /> Text to Speech</span>
          } key="tts">
            <TextToSpeech />
          </TabPane>
          
          <TabPane tab={
            <span><AudioOutlined /> Speech to Text</span>
          } key="stt">
            <SpeechToText />
          </TabPane>
        </Tabs>
      </Card>
    </div>
  );
};
