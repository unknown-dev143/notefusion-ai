import React, { useState } from 'react';
import { Button, Input, Select, Space, Card, Slider, message } from 'antd';
import { SoundOutlined, PlayCircleOutlined, PauseCircleOutlined } from '@ant-design/icons';

const { TextArea } = Input;
const { Option } = Select;

export const TextToSpeech: React.FC = () => {
  const [text, setText] = useState('');
  const [isPlaying, setIsPlaying] = useState(false);
  const [voice, setVoice] = useState('en-US-Standard-A');
  const [rate, setRate] = useState(1.0);
  const [pitch, setPitch] = useState(1.0);
  
  const voices = [
    { value: 'en-US-Standard-A', label: 'US English Female' },
    { value: 'en-US-Standard-B', label: 'US English Male' },
    { value: 'en-GB-Standard-A', label: 'UK English Female' },
    { value: 'en-GB-Standard-B', label: 'UK English Male' },
  ];

  const handlePlay = () => {
    if (!text.trim()) {
      message.warning('Please enter some text to convert to speech');
      return;
    }
    
    setIsPlaying(true);
    // TODO: Implement TTS API call
    console.log('Converting to speech:', { text, voice, rate, pitch });
    
    // Simulate speech completion
    setTimeout(() => {
      setIsPlaying(false);
      message.success('Audio playback completed');
    }, 2000);
  };

  const handlePause = () => {
    // TODO: Implement pause functionality
    setIsPlaying(false);
  };

  return (
    <div className="text-to-speech">
      <Space direction="vertical" style={{ width: '100%' }} size="large">
        <TextArea
          rows={6}
          placeholder="Enter text to convert to speech..."
          value={text}
          onChange={(e) => setText(e.target.value)}
          disabled={isPlaying}
        />
        
        <Card size="small" title="Voice Settings">
          <Space direction="vertical" style={{ width: '100%' }} size="middle">
            <div>
              <div>Voice:</div>
              <Select
                value={voice}
                onChange={setVoice}
                style={{ width: '100%' }}
                disabled={isPlaying}
              >
                {voices.map(v => (
                  <Option key={v.value} value={v.value}>
                    {v.label}
                  </Option>
                ))}
              </Select>
            </div>
            
            <div>
              <div>Speed: {rate.toFixed(1)}x</div>
              <Slider
                min={0.5}
                max={2.0}
                step={0.1}
                value={rate}
                onChange={setRate}
                disabled={isPlaying}
              />
            </div>
            
            <div>
              <div>Pitch: {pitch.toFixed(1)}</div>
              <Slider
                min={0.5}
                max={2.0}
                step={0.1}
                value={pitch}
                onChange={setPitch}
                disabled={isPlaying}
              />
            </div>
          </Space>
        </Card>
        
        <div style={{ textAlign: 'center' }}>
          {isPlaying ? (
            <Button 
              type="primary" 
              icon={<PauseCircleOutlined />} 
              onClick={handlePause}
              size="large"
            >
              Pause
            </Button>
          ) : (
            <Button 
              type="primary" 
              icon={<PlayCircleOutlined />} 
              onClick={handlePlay}
              size="large"
              disabled={!text.trim()}
            >
              Play
            </Button>
          )}
        </div>
      </Space>
    </div>
  );
};
