import React, { Suspense, lazy } from 'react';
import { BrowserRouter, Routes, Route, Navigate, Outlet } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { Spin, ConfigProvider, App as AntdApp, Modal } from 'antd';
// PWA and Service Worker
import PWAInstallPrompt from './components/PWAInstallPrompt';
import pwaManager from './utils/pwaUtils';
import { useEffect, useState } from 'react';
import { AuthProvider } from './features/auth/context/AuthContext';
import { AdminProvider } from './features/admin/context/AdminContext';
import { SearchProvider } from './contexts/SearchContext';
import { AIOrganizationProvider } from './features/ai/context/AIOrganizationContext';
import { RbacProvider } from './features/auth/rbac/RbacContext';
import { NotesPage } from './features/notes';
import { theme } from './theme';
import { InstallButton } from './components/InstallButton';
import { FolderProvider } from './features/folders';
import BackupManager from './features/backup/components/BackupManager';
import ErrorBoundary from './components/ErrorBoundary';
import FeatureFlagsPage from './pages/FeatureFlagsPage';
import { FeatureFlagProvider } from './features/feature-flags';

// Initialize mock service worker in development
const initializeMocks = async () => {
  if (process.env.NODE_ENV === 'development') {
    try {
      const { worker } = await import('./mocks/browser');
      await worker.start({ onUnhandledRequest: 'bypass' });
    } catch (error) {
      console.error('Failed to start mock service worker:', error);
    }
  }
};

// Initialize mocks immediately
initializeMocks().catch(console.error);

// Register service worker on app load
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    pwaManager.registerServiceWorker().catch(console.error);
  });
}

// Lazy load auth pages with error boundary and loading state
const withSuspense = <T extends object>(
  Component: React.ComponentType<T>,
  fallback?: React.ReactNode
) => (props: T) => (
  <Suspense fallback={fallback || <LoadingFallback />}>
    <ErrorBoundary>
      <Component {...props} />
    </ErrorBoundary>
  </Suspense>
);

const LoginPage = withSuspense(lazy(() => import('./features/auth/pages/LoginPage')));
const SignupPage = withSuspense(lazy(() => import('./features/auth/pages/SignupPage')));
const ForgotPasswordPage = withSuspense(lazy(() => import('./features/auth/pages/ForgotPasswordPage')));
const ResetPasswordPage = withSuspense(lazy(() => import('./features/auth/pages/ResetPasswordPage')));
const AudioDemoPage = withSuspense(lazy(() => import('./pages/AudioDemo')));
const VerifyEmailPage = withSuspense(lazy(() => import('./features/auth/pages/VerifyEmailPage')));
const AudioPage = withSuspense(lazy(() => import('./features/audio/pages/AudioPage')));

// Base path for authentication routes
const AUTH_PATH = '/auth';

// Layout component for authentication pages
const AuthLayout = () => (
  <div className="auth-layout" data-testid="auth-layout">
    <div className="auth-container">
      <ErrorBoundary>
        <Outlet />
      </ErrorBoundary>
    </div>
  </div>
);


// Loading fallback component
// Check if the app is running as a PWA
const isRunningAsPWA = () => {
  return window.matchMedia('(display-mode: standalone)').matches || 
         (window.navigator as any).standalone === true;
};

const LoadingFallback = ({ message = 'Loading...' }: { message?: string }) => (
  <div 
    role="status" 
    aria-live="polite"
    aria-busy="true"
    style={{
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center',
      alignItems: 'center',
      minHeight: '100vh',
      backgroundColor: '#f0f2f5',
      padding: '1rem',
      textAlign: 'center'
    }}
  >
    <Spin size="large" />
    <p style={{ marginTop: '1rem', color: '#666' }}>{message}</p>
  </div>
);

// PWA update handling
const useServiceWorker = () => {
  const [updateAvailable, setUpdateAvailable] = useState<boolean>(false);
  const [registration, setRegistration] = useState<ServiceWorkerRegistration | null>(null);

  const updateServiceWorker = () => {
    if (registration?.waiting) {
      registration.waiting.postMessage({ type: 'SKIP_WAITING' });
      window.location.reload();
    }
  };

  // Check for updates when the app loads
  useEffect(() => {
    const checkForUpdates = async () => {
      try {
        const reg = await pwaManager.registerServiceWorker();
        setRegistration(reg);
        
        // Listen for controller change (update available)
        navigator.serviceWorker.addEventListener('controllerchange', () => {
          setUpdateAvailable(true);
        });
        
        // Check for updates every hour
        const interval = setInterval(() => {
          pwaManager.checkForUpdates();
        }, 60 * 60 * 1000);
        
        return () => clearInterval(interval);
      } catch (error) {
        console.error('Service Worker registration failed:', error);
        return undefined;
      }
    };
    
    checkForUpdates();
  }, []);
  
  return { updateAvailable, updateServiceWorker };
};

// Main App component with proper TypeScript types
const App: React.FC = () => {
  const { updateAvailable, updateServiceWorker } = useServiceWorker();
  
  // Handle service worker update
  useEffect(() => {
    if (updateAvailable) {
      Modal.confirm({
        title: 'Update Available',
        content: 'A new version is available. Would you like to update now?',
        onOk: updateServiceWorker,
        okText: 'Update',
        cancelText: 'Later',
      });
    }
  }, [updateAvailable, updateServiceWorker]);

  return (
    <ConfigProvider theme={theme}>
      <AntdApp>
        <BrowserRouter>
          <AuthProvider>
            <RbacProvider>
              <AdminProvider>
                <SearchProvider>
                  <AIOrganizationProvider>
                    <FolderProvider>
                      <FeatureFlagProvider>
                        <Toaster position="top-right" />
                        {/* PWA Install Prompt and Status */}
                        {!isRunningAsPWA() && <PWAInstallPrompt />}
                          
                          <Routes>
                            <Route path={AUTH_PATH} element={<AuthLayout />}>
                              <Route index element={<Navigate to="login" replace />} />
                              <Route path="login" element={<LoginPage />} />
                              <Route path="signup" element={<SignupPage />} />
                              <Route path="verify-email" element={<VerifyEmailPage />} />
                              <Route path="forgot-password" element={<ForgotPasswordPage />} />
                              <Route path="reset-password" element={<ResetPasswordPage />} />
                            </Route>
                            <Route path="/" element={<Navigate to="/notes" replace />} />
                            
                            {/* Notes Routes */}
                            <Route 
                              path="/notes/*" 
                              element={
                                <ErrorBoundary componentName="NotesPage">
                                  <NotesPage />
                                </ErrorBoundary>
                              } 
                            />
                            
                            {/* Backup Routes */}
                            <Route 
                              path="/backups" 
                              element={
                                <ErrorBoundary componentName="BackupManager">
                                  <BackupManager />
                                </ErrorBoundary>
                              } 
                            />
                          </Routes>
                          
                          {/* Main App Routes */}
                          <Routes>
                            <Route path={AUTH_PATH} element={<AuthLayout />}>
                              <Route index element={<Navigate to="login" replace />} />
                              <Route path="login" element={<LoginPage />} />
                              <Route path="signup" element={<SignupPage />} />
                              <Route path="verify-email" element={<VerifyEmailPage />} />
                              <Route path="forgot-password" element={<ForgotPasswordPage />} />
                              <Route path="reset-password" element={<ResetPasswordPage />} />
                            </Route>
                            
                            <Route path="/" element={<Navigate to="/notes" replace />} />
                            
                            {/* Notes Routes */}
                            <Route 
                              path="/notes/*" 
                              element={
                                <ErrorBoundary componentName="NotesPage">
                                  <NotesPage />
                                </ErrorBoundary>
                              } 
                            />
                            
                            {/* Audio Demo Page */}
                            <Route 
                              path="/audio-demo" 
                              element={
                                <ErrorBoundary componentName="AudioDemo">
                                  <AudioDemoPage />
                                </ErrorBoundary>
                              } 
                            />

                            {/* Audio Tools Page */}
                            <Route 
                              path="/audio-tools" 
                              element={
                                <ErrorBoundary componentName="AudioPage">
                                  <AudioPage />
                                </ErrorBoundary>
                              } 
                            />

                            {/* Backup Routes */}
                            <Route 
                              path="/backups" 
                              element={
                                <ErrorBoundary componentName="BackupManager">
                                  <BackupManager />
                                </ErrorBoundary>
                              } 
                            />

                            {/* Feature Flags Page */}
                            <Route 
                              path="/feature-flags" 
                              element={
                                <ErrorBoundary componentName="FeatureFlagsPage">
                                  <FeatureFlagsPage />
                                </ErrorBoundary>
                              } 
                            />

                            {/* 404 Route */}
                            <Route path="*" element={
                              <div style={{ textAlign: 'center', padding: '50px 20px', color: '#666' }}>
                                <h1>404 - Page Not Found</h1>
                                <p>The page you are looking for doesn't exist or has been moved.</p>
                                <div style={{ marginTop: '20px' }}>
                                  <InstallButton />
                                </div>
                              </div>
                            } />
                          </Routes>
                      </FolderProvider>
                    </AIOrganizationProvider>
                  </SearchProvider>
                </AdminProvider>
              </RbacProvider>
            </AuthProvider>
          </FeatureFlagProvider>
        </BrowserRouter>
        <Toaster position="top-right" />
      </AntdApp>
    </Suspense>
  </ConfigProvider>
  );
};

export default App;
